import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output

app = Dash(__name__)

df = pd.read_csv("https://raw.githubusercontent.com/lihkir/Uninorte/main/AppliedStatisticMS/DataVisualizationRPython/Lectures/Python/PythonDataSets/intro_bees.csv")

df = df.groupby(['State', 'ANSI', 'Affected by', 'Year', 'state_code'])[['Pct of Colonies Impacted']].mean()
df.reset_index(inplace=True)

unique_affected_by = df['Affected by'].unique()  # Obtenemos todas las opciones únicas en "Affected by"

app.layout = html.Div([
    html.H1("US State Bee Colony Impact Visualizer", style={'text-align': 'center'}), # Cambiamos el titulo
    dcc.Dropdown(id="slct_year",
                 options=[
                     {"label": "2015", "value": 2015},
                     {"label": "2016", "value": 2016},
                     {"label": "2017", "value": 2017},
                     {"label": "2018", "value": 2018}],
                 multi=False,
                 value=2015,
                 style={'width': "48%", 'display': 'inline-block', 'text-align': 'left'}
                 ),
    dcc.Dropdown(id="slct_affected_by",  # Generamos un nuevo dropdown para la causa
                 options=[
                     {"label": "All Causes", "value": "All"},
                     {"label": "Disease", "value": "Disease"},
                     {"label": "Pesticides", "value": "Pesticides"},
                     {"label": "Varroa mites", "value": "Varroa_mites"},
                     {"label": "Pesticides Excluded Varroa", "value": "Pests_excl_Varroa"},
                     {"label": "Other", "value": "Other"},
                     {"label": "Unknown", "value": "Unknown"}],
                 multi=False,
                 value="All",
                 style={'width': "48%", 'display': 'inline-block'}
                 ),
    html.Div(id='output_container_year', children=[], style={'width': '48%', 'display': 'inline-block', 'text-align': 'left'}),
    html.Div(id='output_container_affected_by', children=[], style={'width': '48%', 'display': 'inline-block'}), # Agregamos un nuevo container
    dcc.Graph(id='my_bee_map', figure={}),
    dcc.Graph(id='scatter_plot', figure={})  # Agregamos un nuevo gráfico de dispersión
])

@app.callback(
    [Output(component_id='output_container_year', component_property='children'),
     Output(component_id='output_container_affected_by', component_property='children'), # Agregamos una nueva salida para el container 
     Output(component_id='my_bee_map', component_property='figure'),
     Output(component_id='scatter_plot', component_property='figure')],  # Agregamos una nueva salida para el gráfico de dispersión
    [Input(component_id='slct_year', component_property='value'),
     Input(component_id='slct_affected_by', component_property='value')] # Agregamos un nuevo input con los affected_by
)
def update_graph(selected_year, selected_affected_by):

    container_year = "The year chosen by user was: {}".format(selected_year)
    container_affected_by = "The causes chosen by user was: {}".format(selected_affected_by)

    dff = df.copy()
    dff= dff[dff["Year"] == selected_year]  
    if selected_affected_by != "All":
        dff= dff[dff["Affected by"] == selected_affected_by]


    fig_map = px.choropleth(
        data_frame=dff,
        locationmode='USA-states',
        locations='state_code',
        scope="usa",
        color='Pct of Colonies Impacted',
        hover_data={'State': True, 'Pct of Colonies Impacted': True, 'Affected by': True, 'state_code': False},  # Agregamos 'Affected by' al hover_data y quitamos el state_code
        color_continuous_scale=px.colors.sequential.GnBu,
        color_continuous_midpoint=50, # Establecemos un punto medio en la escala de colores para unificar todos los años a un mismo rango en escala de colores, y poder comparar
        labels={'Pct of Colonies Impacted': '% of Bee Colonies', 'Affected by': 'Affected by'},
        template='ggplot2'
    )
    
    fig_scatter = px.scatter(  # Creamos un gráfico de dispersión de colonias por estado
        data_frame=dff,
        x='State',
        y='Pct of Colonies Impacted',
        title='Percentage of Colonies Impacted by State',
        labels={'Pct of Colonies Impacted': '% of Bee Colonies'},
        hover_data={'State': True, 'Pct of Colonies Impacted': True, 'Affected by': True}
    )
    
    # Modificaciones en el gráfico de dispersión
    fig_scatter.update_yaxes(range=[0, 100])  # Establecer el rango del eje y de 0 a 100 para todos los años
    fig_scatter.update_xaxes(tickangle=310)

    return [container_year, container_affected_by, fig_map, fig_scatter]  # Agregamos la nueva figura

if __name__ == '__main__':
    app.run_server(debug=True, host='0.0.0.0', port=9000)