from dash import Dash, dcc, html, Input, Output
from dash.dependencies import Input, Output
import colorlover as cl
import pandas as pd

app = Dash(__name__)

colorscale = cl.scales['9']['qual']['Paired']

df = pd.read_csv('https://raw.githubusercontent.com/lihkir/Uninorte/main/AppliedStatisticMS/DataVisualizationRPython/Lectures/Python/PythonDataSets/dash-stock-ticker-demo.csv')

def bbands(price, window_size=10, num_of_std=5):
    rolling_mean = price.rolling(window=window_size).mean()
    rolling_std = price.rolling(window=window_size).std()
    upper_band = rolling_mean + (rolling_std * num_of_std)
    lower_band = rolling_mean - (rolling_std * num_of_std)
    return rolling_mean, upper_band, lower_band

app.layout = html.Div([
    html.Div([
        html.H2('Finance Explorer',
                style={'float': 'left', 
                       'margin-right': '10px'
                       }),
        html.Img(src="https://s3-us-west-1.amazonaws.com/plotly-tutorials/logo/new-branding/dash-logo-by-plotly-stripe.png",
                style={'height': '100px','float': 'right'
                }
        ),
        dcc.Dropdown(id='stock-ticker-input', options=[{'label': s, 'value': s} for s in df.Stock.unique()], value=['YHOO'], multi=True),
        dcc.DatePickerRange(
            id='date-picker-range',
            start_date=df['Date'].min(),
            end_date=df['Date'].max(),
            display_format='YYYY-MM-DD'
        )
    ], style={'padding': '20px'}),
    html.Div(id='graphs', style={'padding': '20px'})
])

@app.callback(Output('graphs','children'),
    [Input('stock-ticker-input', 'value'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')])
def update_graph(tickers, start_date, end_date):
    graphs = []

    df_filtered = df[(df['Date'] >= start_date) & (df['Date'] <= end_date)]

    for ticker in tickers:
        dff = df_filtered[df_filtered['Stock'] == ticker]
        
        candlestick = {
            'x': dff['Date'],
            'open': dff['Open'],
            'high': dff['High'],
            'low': dff['Low'],
            'close': dff['Close'],
            'type': 'candlestick',
            'name': ticker,
            'legendgroup': ticker,
            'yaxis': 'y2'
        }
        
        bb_bands = bbands(dff.Close)
        bollinger_traces = [{
            'x': dff['Date'], 'y': y,
            'type': 'scatter', 'mode': 'lines',
            'line': {'width': 1}
        } for y in bb_bands]
        
        volume_bar = {
            'x': dff['Date'],
            'y': dff['Volume'],
            'type': 'bar', 'name': 'Volume',
            'yaxis': 'y'
        }

        layout = {
            'title': ticker,
            'yaxis': {'title': 'Volume'},
            'yaxis2': {'title': 'Stock Price', 'overlaying': 'y', 'side': 'right'},
            'margin': {'b': 40, 'r': 40, 'l': 60, 't': 40},
            'legend': {'x': 0}
        }

        graphs.append(dcc.Graph(
            id=ticker,
            figure={
                'data': [candlestick, volume_bar] + bollinger_traces,
                'layout': layout
            }
        ))

    return graphs

if __name__ == '__main__':
    # app.run_server(debug=True)
    app.run_server(debug=True, host='0.0.0.0', port=9000)